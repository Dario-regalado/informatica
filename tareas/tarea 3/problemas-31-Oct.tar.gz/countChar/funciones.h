#include <iostream>

int countVowels (const std::string& imput);
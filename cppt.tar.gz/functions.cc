/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author Kyrylo Chvanov alu0101640440@ull.edu.es
  * @date MONTH DAY YEAR
  * @brief DESCRIPTION
  * @bug There are no known bugs
  * @see
  */

#include "functions.h"


#include "triangle.h"

namespace triangle {

}  // namespace triangle

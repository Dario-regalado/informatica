#if !defined(TRIANGLE_H)
#define TRIANGLE_H

namespace triangle {

}  // namespace triangle

#endif // TRIANGLE_H
#if !defined(GRADE_SCHOOL_H)
#define GRADE_SCHOOL_H

namespace grade_school {

}  // namespace grade_school

#endif // GRADE_SCHOOL_H
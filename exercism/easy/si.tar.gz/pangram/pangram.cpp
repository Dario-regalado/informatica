#include "pangram.h"

namespace pangram {

}  // namespace pangram

#if !defined(PANGRAM_H)
#define PANGRAM_H

namespace pangram {

}  // namespace pangram

#endif // PANGRAM_H
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @author  Dario Regalado Gonzalez alu0101640150@ull.edu.es
  * @date Nov 30 2023
  * @brief 
  * @bug There are no known bugs
  * @see
  */

#pragma once
#include <fstream>
#include <iostream>


void ConbineWords (std::ifstream &first_file, std::ifstream &second_file);